<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
    <div class="layout">
        <RouterView />
    </div>

</template>

