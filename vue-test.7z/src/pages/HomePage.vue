<script setup>
import UserInfo from "../components/UserInfo/UserInfo.vue";
</script>

<template>
    <div class="wrapper">
        <UserInfo/>
    </div>
</template>
