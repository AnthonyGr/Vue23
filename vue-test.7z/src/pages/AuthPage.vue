<script setup>
import AuthByLogin from "../components/AuthByLogin/AuthByLogin.vue";
</script>

<template>
    <div class="wrapper">
        <AuthByLogin/>
    </div>
</template>
